
export const ERROR_NO_MESH = (entity) => new Error(`No Mesh found on entity.\n\t${entity}`);